package final_project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class WebNode {
	public WebNode parent;
	public ArrayList<WebNode> children;
	public WebPage webPage;	
	public double nodeScore; //This node's score += all its children's nodeScore
	
	public WebNode(WebPage webPage){
		this.webPage = webPage;
		this.children = new ArrayList<WebNode>();		
		
	}
	
	public void setNodeScore(Keyword keywords) throws IOException{
		//this method should be called in post-order mode
		
		//compute webPage score
        int christmasCount = webPage.counter.countKeywords(keywords.getChristmasKeywords());
        int eventCount = webPage.counter.countKeywords(keywords.getEventKeywords());
        int socialMediaCount = webPage.counter.countKeywords(keywords.getSocialMediaKeywords());
        int minusCount = webPage.counter.countKeywords(keywords.getMinusKeywords());
        
		webPage.setScore(christmasCount,eventCount,socialMediaCount,minusCount);
		//set webPage score to nodeScore
		nodeScore = webPage.score;

		//nodeScore += all children's nodeScore 
		for(WebNode child : children){
			nodeScore += child.nodeScore;
		}			
	}
	
	public void addChild(WebNode child){
		//add the WebNode to its children list
		this.children.add(child);
		child.parent = this;
	}
	
	public boolean isTheLastChild(){
		if(this.parent == null) return true;
		ArrayList<WebNode> siblings = this.parent.children;
		
		return this.equals(siblings.get(siblings.size() - 1));
	}
	
	public int getDepth(){
		int retVal = 1;
		WebNode currNode = this;
		while(currNode.parent != null){
			retVal++;
			currNode = currNode.parent;
		}
		return retVal;
	}
	public String getNodeDetails() {
        return webPage.url + " " + webPage.name + " " + nodeScore;
    }
	public void updateEventKeywordsWithFrequentWords(String content, Keyword keywords, int topN) {
  
        HashMap<String, Integer> wordCount = new HashMap<>();
        StringTokenizer tokenizer = new StringTokenizer(content.toLowerCase());
        while (tokenizer.hasMoreTokens()) {
            String word = tokenizer.nextToken();
            wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
        }

   
        List<Map.Entry<String, Integer>> list = new ArrayList<>(wordCount.entrySet());
        list.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));


        for (int i = 0; i < Math.min(topN, list.size()); i++) {
            Map.Entry<String, Integer> entry = list.get(i);
            String word = entry.getKey();

            if (!keywords.getEventKeywords().contains(word)) {
                keywords.getEventKeywords().add(word);
            }
        }
    }
	
	// 在 WebNode 類別中添加一個方法
	public List<WebNode> getTopTwoChildren() {
        List<WebNode> sortedChildren = new ArrayList<>(children);
        Collections.sort(sortedChildren, Comparator.comparingDouble(childNode -> childNode.nodeScore));
        Collections.reverse(sortedChildren); // 降序排序
        return sortedChildren.subList(0, Math.min(2, sortedChildren.size())); // 取前兩個子網頁
    }
	// 在 WebNode 類別中添加一個方法
	public void addChildrenToTree(WebTree tree, Keyword keywords) throws IOException {
	    for (WebNode child : children) {
	        tree.root.addChild(child);
	        child.setNodeScore(keywords); // 計算子網頁的分數
	        child.addChildrenToTree(tree, keywords); // 遞歸添加子網頁
	    }
	}

	

}