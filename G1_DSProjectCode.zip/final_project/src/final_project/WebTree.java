package final_project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebTree {
	public WebNode root;
	
	public WebTree(WebPage rootPage){
		this.root = new WebNode(rootPage);
	}
	
	public void setPostOrderScore(Keyword keywords) throws IOException{
		setPostOrderScore(root, keywords);
	}
	
	private void setPostOrderScore(WebNode startNode, Keyword keywords) throws IOException{
		//2. compute the score of children nodes via post-order
		for(WebNode child : startNode.children){
			setPostOrderScore(child, keywords);		
		}
		//setNode score of startNode
		startNode.setNodeScore(keywords);
		}
	
	public void eularPrintTree(){
		eularPrintTree(root);
	}
	
	private void eularPrintTree(WebNode startNode){
		int nodeDepth = startNode.getDepth();
		
		if(nodeDepth > 1) System.out.print("\n" + repeat("\t", nodeDepth-1));

		System.out.print("(");
		System.out.print(startNode.webPage.name + "," + startNode.nodeScore);
		
		//3.print child via pre-order
		for(WebNode child : startNode.children){
			eularPrintTree(child);		
		}
		
		System.out.print(")");
		
		if(startNode.isTheLastChild()) System.out.print("\n" + repeat("\t", nodeDepth-2));
		
	}
	
	private String repeat(String str, int repeat){
		String retVal = "";
		for(int i = 0; i < repeat; i++){
			retVal += str;
		}
		return retVal;
	}
	public String getMostFrequentTwoCharacterChineseWord() throws IOException {
        Map<String, Integer> wordFrequency = new HashMap<>();
        

        countTwoCharacterChineseWords(root, wordFrequency);

     
        return wordFrequency.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }
    
    private void countTwoCharacterChineseWords(WebNode node, Map<String, Integer> wordFrequency) throws IOException {
        if (node != null) {
            String content = node.webPage.counter.fetchContent(); // Assumes fetchContent() is public
       
            Matcher matcher = Pattern.compile("[\\u4e00-\\u9fa5]{2}").matcher(content);

            while (matcher.find()) {
                String word = matcher.group();
                wordFrequency.put(word, wordFrequency.getOrDefault(word, 0) + 1);
            }

         
            for (WebNode child : node.children) {
                countTwoCharacterChineseWords(child, wordFrequency);
            }
        }
    }
}