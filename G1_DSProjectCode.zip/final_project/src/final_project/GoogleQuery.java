package final_project;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {
    public String searchKeyword;
    public String url;
    public String content;

    public GoogleQuery(String searchKeyword) {
        this.searchKeyword = searchKeyword;
        try {
            String encodeKeyword = java.net.URLEncoder.encode(searchKeyword, "utf-8");
            this.url = "https://www.google.com/search?q=" + encodeKeyword + "&oe=utf8&num=20";
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private String fetchContent() throws IOException {
        String retVal = "";

        URL u = new URL(url);
        URLConnection conn = u.openConnection();
        // set HTTP header
        conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
        InputStream in = conn.getInputStream();

        InputStreamReader inReader = new InputStreamReader(in, "utf-8");
        BufferedReader bufReader = new BufferedReader(inReader);
        String line = null;

        while ((line = bufReader.readLine()) != null) {
            retVal += line;
        }
        return retVal;
    }
    
    public String fetchChildContent(String childUrl) throws IOException {
        URL childU = new URL(childUrl);
        URLConnection childConn = childU.openConnection();
        InputStream childIn = childConn.getInputStream();

        InputStreamReader childInReader = new InputStreamReader(childIn, "utf-8");
        BufferedReader childBufReader = new BufferedReader(childInReader);
        StringBuilder childContent = new StringBuilder();
        String childLine;

        while ((childLine = childBufReader.readLine()) != null) {
            childContent.append(childLine);
        }

        return childContent.toString();
    }

    private String cleanGoogleSearchResultUrl(String citeUrl) {
        try {
     
            String decodedUrl = URLDecoder.decode(citeUrl, "UTF-8");


            String regex = "&sa=.*$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(decodedUrl);

            if (matcher.find()) {
     
                decodedUrl = decodedUrl.replaceAll(regex, "");
            }


            regex = "&ved=.*$";
            pattern = Pattern.compile(regex);
            matcher = pattern.matcher(decodedUrl);

            if (matcher.find()) {
          
                decodedUrl = decodedUrl.replaceAll(regex, "");
            }

            return decodedUrl;
        } catch (IOException e) {
            e.printStackTrace();
            return citeUrl;
        }
    }

    public HashMap<String, String> query() throws IOException {
        if (content == null) {
            content = fetchContent();
        }

        HashMap<String, String> retVal = new HashMap<String, String>();

        Document doc = Jsoup.parse(content);
        Elements lis = doc.select("div");
        lis = lis.select(".kCrYT");

        for (Element li : lis) {
            try {
                String citeUrl = li.select("a").get(0).attr("href").replace("/url?q=", "");
                String cleanedUrl = cleanGoogleSearchResultUrl(citeUrl);
                String title = li.select("a").get(0).select(".vvjwJb").text();

                if (title.equals("")) {
                    continue;
                }
                
                

                //System.out.println("Title: " + title + " , url: " + cleanedUrl);

                retVal.put(title, cleanedUrl);

            } catch (IndexOutOfBoundsException e) {
            }
        }

        return retVal;
    }
}