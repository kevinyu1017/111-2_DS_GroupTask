package final_project;
public class SearchResult {
    private String title;
    private String childContent;

    public SearchResult(String title, String childContent) {
        this.title = title;
        this.childContent = childContent;
    }

    public String getTitle() {
        return title;
    }

    public String getChildContent() {
        return childContent;
    }
}
