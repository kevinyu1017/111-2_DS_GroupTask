package final_project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {    	
        try {
            Scanner scanner = new Scanner(System.in);

      
            System.out.println("Enter the search query: ");

   
            String searchQuery = scanner.nextLine();

            HashMap<String, String> googleSearchResultMap = new GoogleQuery(searchQuery).query();

      
            WebPage rootPage = new WebPage("https://www.google.com", "Search Result");
            WebTree tree = new WebTree(rootPage);

            // 印出搜尋結果
            for (String key : googleSearchResultMap.keySet()) {
                System.out.println(key + ": " + googleSearchResultMap.get(key));
                String url = googleSearchResultMap.get(key); // This should already be a valid URL.
                String title = key;
                WebNode childNode = new WebNode(new WebPage(url, title));
                tree.root.addChild(childNode);
            }
            
            //使用後序排序
            Keyword keywords = new Keyword();
            tree.setPostOrderScore(keywords);
               
            List<WebNode> nodeList = getAllNodes(tree.root);

   
            Collections.sort(nodeList, new Comparator<WebNode>() {
                @Override
                public int compare(WebNode node1, WebNode node2) {
                    return Double.compare(node2.nodeScore, node1.nodeScore); // 降序
                }
            });
            try {
            	String mostFrequentWord = tree.getMostFrequentTwoCharacterChineseWord();
                System.out.println("Most frequent two-character Chinese word across all nodes: " + mostFrequentWord);
            } catch (IOException e) {
                System.err.println("Error occurred: " + e.getMessage());
                e.printStackTrace();
            }

     
            for (WebNode node : nodeList) {
                System.out.println(node.getNodeDetails());
            }
            
        }catch (IOException e) {
            e.printStackTrace();            
        }
        
        
    }
    
    public static List<WebNode> getAllNodes(WebNode startNode) {
        ArrayList<WebNode> nodeList = new ArrayList<>();
        nodeList.add(startNode); 
        for (WebNode child : startNode.children) {
            nodeList.addAll(getAllNodes(child)); 
        }
        return nodeList;
    }
}

