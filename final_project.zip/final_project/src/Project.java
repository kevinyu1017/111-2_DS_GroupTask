import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import final_project.GoogleQuery;
import final_project.Keyword;
import final_project.WebNode;
import final_project.WebPage;
import final_project.WebTree;

import java.awt.SystemColor;

public class Project {

    private JFrame frame;
    private JLayeredPane layeredPane;
    private JLabel label;
    private JTextField txtSearch;
    private JButton btnConfirm;


    public static void main(String[] args) {
    	disableCertificateValidation();  	
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    Project window = new Project();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public Project() {
        initialize();
    }
    

    private void initialize() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        layeredPane = new JLayeredPane();
        frame.getContentPane().add(layeredPane, BorderLayout.CENTER);

        ImageIcon imageIcon = new ImageIcon(getClass().getResource("portal.png"));


        label = new JLabel(new ImageIcon(imageIcon.getImage()));
        label.setBounds(0, 0, 799, 532);
        layeredPane.add(label, JLayeredPane.DEFAULT_LAYER);

        txtSearch = new JTextField("");
        txtSearch.setBackground(SystemColor.text);
        txtSearch.setForeground(SystemColor.activeCaptionText); 
        txtSearch.setFont(new Font("微軟正黑體", Font.PLAIN, 20)); 
        txtSearch.setBounds(0, 0, imageIcon.getIconWidth(), 30); 
        txtSearch.setHorizontalAlignment(JTextField.CENTER); 
        layeredPane.add(txtSearch, JLayeredPane.PALETTE_LAYER);

        // 當點擊文本框時，清空原有文字
        txtSearch.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtSearch.getText().equals("search")) {
                    txtSearch.setText("");
                    txtSearch.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtSearch.getText().trim().isEmpty()) {
                    txtSearch.setText("search");
                    txtSearch.setForeground(new Color(150, 150, 150));
                }
            }
        });


        btnConfirm = new JButton("Search");
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
    
                GoogleQuery googleQuery = new GoogleQuery(txtSearch.getText());
                HashMap<String, String> searchResults = null;
                try {
                    searchResults = googleQuery.query();
               

                    // 建立根節點
                    WebPage rootPage = new WebPage("https://www.google.com", "Search Result");
                    WebTree tree = new WebTree(rootPage);

                    // 搜尋結果加入到樹
                    for (Map.Entry<String, String> entry : searchResults.entrySet()) {
                        WebNode node = new WebNode(new WebPage(entry.getValue(), entry.getKey()));
                        tree.root.addChild(node);
                    }

    
                    tree.setPostOrderScore(new Keyword());
  
                    List<WebNode> nodeList = getAllNodes(tree.root);
                    
                    // 用分數排序
                    Collections.sort(nodeList, new Comparator<WebNode>() {
                        public int compare(WebNode n1, WebNode n2) {
                            return Double.compare(n2.nodeScore, n1.nodeScore); // 降序
                        }
                    });

       
                    Christmas christmasPage = new Christmas();

  
                    christmasPage.setSearchResults(nodeList);
    
                    createNewPage("Christmas Page", christmasPage);
                    
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        });

        btnConfirm.setBounds((imageIcon.getIconWidth() - 100) / 2, 40, 100, 30); // 設置初始位置和大小
        layeredPane.add(btnConfirm, JLayeredPane.PALETTE_LAYER);


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        frame.setLocationRelativeTo(null);


        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent evt) {
                frameResized(evt);
            }
        });

        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);

        frame.requestFocus();
    }


    private void frameResized(ComponentEvent evt) {

        updateImageAndTextFieldPosition();
    }

    // 更新圖片和TextField的位置
    private void updateImageAndTextFieldPosition() {

        Dimension newSize = frame.getSize();

        ImageIcon imageIcon = new ImageIcon(getClass().getResource("portal.png"));
        Image newImage = imageIcon.getImage().getScaledInstance(newSize.width, newSize.height, Image.SCALE_DEFAULT);
        label.setIcon(new ImageIcon(newImage));
        label.setBounds(0, 0, newSize.width, newSize.height);
        int textFieldWidth = newSize.width / 2; // 設定 TextField 寬度為畫面寬度的一半
        int textFieldHeight = 30;
        int textFieldX = (newSize.width - textFieldWidth) / 2; // 使 TextField 居中
        int textFieldY = newSize.height / 2 - textFieldHeight / 2; // 使 TextField 垂直居中

        txtSearch.setBounds(textFieldX, textFieldY, textFieldWidth, textFieldHeight);


        // 調整Confirm button的位置
        btnConfirm.setBounds(textFieldX + textFieldWidth + 10, textFieldY, 100, 30);

    }
    private void createNewPage(String pageTitle, Christmas christmasPage) {

        JFrame nextPageFrame = new JFrame(pageTitle);


        nextPageFrame.getContentPane().add(christmasPage);

   
        nextPageFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        nextPageFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        nextPageFrame.setVisible(true);
        nextPageFrame.setLocationRelativeTo(null);
    }
    private void runSearchAndDisplayResults() {
        String searchQuery = txtSearch.getText();
        GoogleQuery googleQuery = new GoogleQuery(searchQuery);
        try {
            HashMap<String, String> searchResults = googleQuery.query();
            WebTree webTree = new WebTree(new WebPage("https://www.google.com", "Search Result"));


            for (Map.Entry<String, String> entry : searchResults.entrySet()) {
                webTree.root.addChild(new WebNode(new WebPage(entry.getValue(), entry.getKey())));
            }

   
            Keyword keywords = new Keyword();
            webTree.setPostOrderScore(keywords);

            List<WebNode> sortedNodes = getAllNodes(webTree.root);
            Collections.sort(sortedNodes, new Comparator<WebNode>() {
                @Override
                public int compare(WebNode node1, WebNode node2) {
                    return Double.compare(node2.nodeScore, node1.nodeScore);
                }
            });

            displayResultsInNewWindow(sortedNodes);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private List<WebNode> getAllNodes(WebNode node) {
        List<WebNode> nodeList = new ArrayList<>();
        if (node == null) return nodeList;
        nodeList.add(node);
        
        for (WebNode childNode : node.children) {
            nodeList.addAll(getAllNodes(childNode));
        }        
        return nodeList;
    }
    private void displayResultsInNewWindow(List<WebNode> sortedNodes) {
        Christmas christmasPage = new Christmas();
        christmasPage.setSearchResults(sortedNodes);
        JFrame resultFrame = new JFrame("Search Results");
        resultFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        resultFrame.setContentPane(christmasPage);
        resultFrame.setSize(800, 600);
        resultFrame.setVisible(true);
    }
    public static void disableCertificateValidation() {
        TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                public void checkServerTrusted(X509Certificate[] certs, String authType) { }
            }
        };
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

}
