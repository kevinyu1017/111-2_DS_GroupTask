package final_project;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class WordCounter {
    private String urlStr;
    private String content;

    public WordCounter(String urlStr) {
        this.urlStr = urlStr;
    }

    public String fetchContent() throws IOException {
    	if (this.urlStr == null || (!this.urlStr.startsWith("http://") && !this.urlStr.startsWith("https://"))) {
            throw new MalformedURLException("Invalid URL: " + this.urlStr);
        }
        try {
            URL url = new URL(urlStr);
            URLConnection conn = url.openConnection();

            // Set User-Agent header to simulate a browser request
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3");

            try {
                return readInputStream(conn.getInputStream());
            } catch (IOException e) {
                InputStream errorStream = ((HttpURLConnection) conn).getErrorStream();
                if (errorStream != null) {
                    return readInputStream(errorStream);
                } else {
                    throw e;
                }
            }
        } catch (MalformedURLException e) {
            // Handle MalformedURLException
            System.err.println(e.getMessage());
            throw e;
        }
    }


    // 讀取輸入流的輔助方法
    private String readInputStream(InputStream inputStream) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder retVal = new StringBuilder();
        String line;

        while ((line = br.readLine()) != null) {
            retVal.append(line).append("\n");
        }

        return retVal.toString();
    }

    public int countKeywords(ArrayList<String> keywords) throws IOException {
        if (content == null) {
            content = fetchContent();
        }

        // count times in keywordList
        int retVal = 0;

        for (String keyword : keywords) {
            int fromIdx = 0;
            int found = -1;

            while ((found = content.indexOf(keyword, fromIdx)) != -1) {
                retVal++;
                fromIdx = found + keyword.length();
            }
        }
        return retVal;
    }
    public void printMostFrequentKeywords(String content, int numberOfKeywords) {
        // Split the content into words and count their occurrences
        Map<String, Integer> wordCounts = new HashMap<>();
        StringTokenizer tokenizer = new StringTokenizer(content.toLowerCase());
        while (tokenizer.hasMoreTokens()) {
            String word = tokenizer.nextToken().replaceAll("[^a-zA-Z0-9]", ""); // remove punctuation
            if (!word.isEmpty()) {
                wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
            }
        }

        // Sort the word counts by frequency in descending order
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(wordCounts.entrySet());
        sortedEntries.sort(Map.Entry.<String, Integer>comparingByValue().reversed());

        // Print out the top numberOfKeywords frequent words
        System.out.println("Most frequent keywords:");
        for (int i = 0; i < Math.min(numberOfKeywords, sortedEntries.size()); i++) {
            Map.Entry<String, Integer> entry = sortedEntries.get(i);
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

 
}
