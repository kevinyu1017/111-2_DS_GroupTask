import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.event.HyperlinkEvent;

import final_project.WebNode;

import java.util.List; 
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Christmas extends JPanel {

    private JFrame frame;
    private Image backgroundImage;
    private JButton btnBack;
    private JTextPane textPaneSearchResults;
    private JScrollPane scrollPane;


    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Christmas window = new Christmas();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Christmas() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        backgroundImage = new ImageIcon(getClass().getResource("christmas.png")).getImage();

        btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBackToProjectPage();
            }
        });

   
        textPaneSearchResults = new JTextPane();
        textPaneSearchResults.setEditable(false);
        textPaneSearchResults.setContentType("text/html");
        textPaneSearchResults.addHyperlinkListener(e -> {
            if (HyperlinkEvent.EventType.ACTIVATED.equals(e.getEventType())) {
                Desktop desktop = Desktop.getDesktop();
                try {
                    desktop.browse(e.getURL().toURI());
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        });

        scrollPane = new JScrollPane(textPaneSearchResults);
        scrollPane.setPreferredSize(new Dimension(900, 300));
        
        
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weighty = 1;

        add(btnBack, gbc);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 10, 10, 10); // Add some space around the component
        add(scrollPane, gbc);

        // Modify frame to add instance of Christmas which is a JPanel
        frame.add(this);

        // Ensure the component has a preferred size for proper resizing
        setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight()));
    }
    
    private String findMostFrequentChineseWord(List<WebNode> nodes) throws IOException {
        Map<String, Integer> frequencyMap = new HashMap<>();

        // 使用正则表达式来找到所有的中文组合
        Pattern pattern = Pattern.compile("[\\u4e00-\\u9fa5]{2}");

        for (WebNode node : nodes) {
            String content = node.webPage.counter.fetchContent(); // 得到網頁內容
            Matcher matcher = pattern.matcher(content);

            while (matcher.find()) {
                String chineseWord = matcher.group();
                frequencyMap.put(chineseWord, frequencyMap.getOrDefault(chineseWord, 0) + 1);
            }
        }
        String mostFrequentWord = Collections.max(frequencyMap.entrySet(), Map.Entry.comparingByValue()).getKey();
        return mostFrequentWord;// 找到频率最高的单词
    }

    public void setSearchResults(List<WebNode> sortedNodes) {
        StringBuilder sb = new StringBuilder("<html>");
        try {
            String mostFrequentWord = findMostFrequentChineseWord(sortedNodes);
            sb.append("出現頻率最高: ").append(mostFrequentWord).append("<br><br>");
        } catch (IOException e) {
            e.printStackTrace();
        }

        int rank = 1;
        for (WebNode node : sortedNodes) {
            sb.append(rank).append(". <a href=\"").append(node.webPage.url).append("\">")
              .append(node.webPage.url).append("</a> ")
              .append(node.webPage.name).append(" ")
              .append(node.nodeScore)
              .append("<br>");
            rank++;
        }
        sb.append("</html>");
        textPaneSearchResults.setText(sb.toString());
    }


    private void goBackToProjectPage() {
        frame.dispose();
        Project projectPage = new Project();
        projectPage.main(null);
    }



    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the background image
        g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
    }
}

